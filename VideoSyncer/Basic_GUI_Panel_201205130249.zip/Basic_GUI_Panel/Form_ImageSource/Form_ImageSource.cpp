// Form_ImageSource.cpp : main project file.

#include "Form1.h"

using namespace Form_ImageSource;

int main(array<System::String ^> ^args);

void trans_IplImage_2_ClassOpenCVMat(IplImage* srcImg, ClassOpenCVMat* mMatTemp, ClassOpenCVMat* mMatColorDisplayImage)
{
	CvMat* pDesImage = cvGetMat( srcImg, mMatTemp->mpMat );
	cvCopy( pDesImage, mMatColorDisplayImage->mpMat );
}

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 

	// Create the main window and run it
	Application::Run(gcnew Form1());	

	return 0;
}


void Form1::mInitializeMyObjects()
{
	this->pictureBox3->Size = System::Drawing::Size(mWidthCapturedImage, mHeightCapturedImage);
	this->pictureBox4->Size = System::Drawing::Size(mWidthCapturedImage, mHeightCapturedImage);

	mImageSourceWebCam = new C_ImageSourceWebCam;
	mImageSourceWebCam->initialize( cvPoint(mWidthCapturedImage,mHeightCapturedImage) ); //->mInitializeGray(1, cvPoint(320,240), miResizeSize[0], miLT[0], miRB[0]);

	mpCounterForFPS=new CPerformanceCounter;
	mpCounterForProcessingTime=new CPerformanceCounter;

	////-------------initialize the set (matColorDisplayImage, pToDisplayImage, mBitMapImage) for GUI real-time display
	matColorDisplayImage=new ClassOpenCVMat;
	matColorDisplayImage->mCreateRGBUCMat(mWidthCapturedImage,mHeightCapturedImage);
	//assign the buffer head pointer to the bitmap
	IntPtr pToDisplayImage(matColorDisplayImage->mpUCArray);
	mBitMapImage=gcnew System::Drawing::Bitmap(mWidthCapturedImage,mHeightCapturedImage,mWidthCapturedImage*3,
		System::Drawing::Imaging::PixelFormat::Format24bppRgb, pToDisplayImage);
	////---------------------------------------------------------------------------------------------------------------

	////-------------initialize the set (matColorDisplayResult, pToDisplayResult, mBitMapResult) for GUI real-time display
	matColorDisplayResult=new ClassOpenCVMat;
	matColorDisplayResult->mCreateRGBUCMat(mWidthCapturedImage,mHeightCapturedImage);
	//assign the buffer head pointer to the bitmap
	IntPtr pToDisplayResult(matColorDisplayResult->mpUCArray);
	mBitMapResult=gcnew System::Drawing::Bitmap(mWidthCapturedImage,mHeightCapturedImage,mWidthCapturedImage*3,
		System::Drawing::Imaging::PixelFormat::Format24bppRgb, pToDisplayResult);
	////---------------------------------------------------------------------------------------------------------------

	////---------allocate matTmp for trans_IplImage_2_ClassOpenCVMat
	matTemp = new ClassOpenCVMat;
	matTemp->mCreateRGBUCMat(mWidthCapturedImage,mHeightCapturedImage);
	////---------------------------------------------------------------------------------------------------------------

	////--------------pass (matColorDisplayImage, matColorDisplayResult) for later use of tracker (OpticalFlow, CAMShift...)
///	motionDetection->initialize( matColorDisplayImage, matColorDisplayResult );
	////---------------------------------------------------------------------------------------------------------------

	imageTemp = cvCreateImage( cvSize(mWidthCapturedImage,mHeightCapturedImage), 8, 3 );

	//Flags and Index
	miFrameIndex=0;
	mbGrab=false;
	mbStep=false;
	mStartCount = true;
	
	txtFrameIndex->Text = miFrameIndex.ToString();
	textProcessTime->Text = miFrameIndex.ToString();

	take_A_image = 0;
}

void Form1::mReleaseMyObjects()
{
	delete matColorDisplayImage;
	delete matColorDisplayResult;
	delete mpCounterForFPS;
	delete mpCounterForProcessingTime;
	delete mImageSourceWebCam;

}

IplImage* Form1::getCurrnentImageFromCam()
{
	return mImageSourceWebCam->grabImage();
}

void Form1::mProcessLoop()
{
	if(mbGrab || mbStep)
	{
		mbStep=false;

		miFrameIndex++;

		//Convert the gray buffer to the display color buffer
		IplImage *pImageSource = getCurrnentImageFromCam();
		//IplImage *pImageSource = cvLoadImage("take_A_image.bmp", 1);

		if (take_A_image)
		{
			//cvSaveImage("take_image.bmp", pImageSource);
			
			take_A_image = 0;

		}

		mpCounterForProcessingTime->StartCount();

		cvCopy(pImageSource, imageTemp);
		cvZero(imageTemp);

		trans_IplImage_2_ClassOpenCVMat(pImageSource, matTemp, matColorDisplayImage);
		trans_IplImage_2_ClassOpenCVMat(imageTemp, matTemp, matColorDisplayResult);

		mpCounterForProcessingTime->EndCount();

		//================================
///		showTrackingMessage( motionDetection->getNormalMessage(), motionDetection->getControlMessage() );
	}

	mShowTimer();

	////------------display processed (matColorDisplayImage, matColorDisplayResult) on GUI panel
	this->pictureBox3->Image=mBitMapImage; // show image
	this->pictureBox4->Image=mBitMapResult; // show image
	////---------------------------------------------------------------------------------------------------------------

}

void Form1::MarshalString( String ^ s, string& os )
{
	   using namespace Runtime::InteropServices;
	   const char* chars = 
		  (const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
	   os = chars;
	   Marshal::FreeHGlobal(IntPtr((void*)chars));
}

void Form1::mShowFPS( int fps )
{
	//frameIndex
	txtFrameIndex->Text = fps.ToString();
}

void Form1::mShowTimer()
{
	//processing time
	textProcessTime->Text = mpCounterForProcessingTime->CalculateElapsedTime().ToString();
}

System::String^	 Form1::stdString2SystemString( string s )
{
	return Marshal::PtrToStringAnsi(static_cast<IntPtr>(const_cast<char *>(s.c_str())));
}

void Form1::showTrackingMessage( string *normalMessage, string *controlMessage )
{
	static int mCountNormal = 0;
	static int mCountControl = 0;

	mCountNormal += normalMessage->size();
	mCountControl += controlMessage->size();

	if( mCountNormal >= 1000 )
	{
		normalMessagePresenter->Clear();
		mCountNormal = 0;
	}
	if( mCountControl >= 1000 )
	{
		controlMessagePresenter->Clear();
		mCountControl = 0;
	}

	normalMessagePresenter->AppendText( stdString2SystemString( *normalMessage ) );
	controlMessagePresenter->AppendText( stdString2SystemString( *controlMessage ) );
	
	normalMessage->clear();
	controlMessage->clear();
}

void Form1::showPMMessage( const string& result)
{
	static int mCountControl = 0;

	mCountControl += result.size();

	normalMessagePresenter->AppendText( stdString2SystemString( result ) + "\n" );
}